package com.cognizant.springlearn;

public class Department {

}
